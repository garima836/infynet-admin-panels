import {
  MdDashboard,
  MdRouter,
  MdSubscriptions,
  MdInsights,
  MdPeople,
  MdSettings,
} from "react-icons/md"
import "./Sidebar.css"

export default function ISPSidebar({ activePage, setPage }) {
  const menu = [
    { id: "dashboard", label: "Dashboard", icon: <MdDashboard /> },
    { id: "providers", label: "Providers", icon: <MdRouter /> },
    { id: "plans", label: "Plans", icon: <MdSubscriptions /> },
    { id: "analytics", label: "Analytics", icon: <MdInsights /> },
    { id: "users", label: "Users", icon: <MdPeople /> },
    { id: "settings", label: "Settings", icon: <MdSettings /> },
  ]

  return (
    <aside className="sidebar">
      <img
        src="https://res.cloudinary.com/dzp296lmx/image/upload/v1769532616/Infynet_TM_Logo_nvjuqw.png"
        alt="Infynet"
        className="logo"
      />

      {menu.map(item => (
        <div
          key={item.id}
          className={`sidebar-item ${activePage === item.id ? "active" : ""}`}
          onClick={() => setPage(item.id)}
        >
          {item.icon}
          <span>{item.label}</span>
        </div>
      ))}
    </aside>
  )
}
