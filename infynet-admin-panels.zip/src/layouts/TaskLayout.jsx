import { useState } from "react"
import TaskSidebar from "../components/Sidebar/TaskSidebar"
import Topbar from "../components/Topbar/Topbar"

import Dashboard from "../pages/tasks/Dashboard"
import Tasks from "../pages/tasks/Tasks"
import Users from "../pages/tasks/Users"
import Reports from "../pages/tasks/Reports"
import Settings from "../pages/tasks/Settings"

export default function TaskLayout() {
  const [page, setPage] = useState("dashboard")

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <TaskSidebar activePage={page} setPage={setPage} />

      <main style={{ flex: 1, padding: 20 }}>
        <Topbar title="Task Management Panel" />

        {page === "dashboard" && <Dashboard />}
        {page === "tasks" && <Tasks />}
        {page === "users" && <Users />}
        {page === "reports" && <Reports />}
        {page === "settings" && <Settings />}
      </main>
    </div>
  )
}
