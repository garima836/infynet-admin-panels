import { useNavigate } from "react-router-dom"
import "./Login.css"

export default function Login() {
  const navigate = useNavigate()

  return (
    <div className="login-container">
      <h1>INFYNET Login</h1>

      <div className="login-actions">
        <button onClick={() => navigate("/isp")}>
          Login as ISP Admin
        </button>

        <button onClick={() => navigate("/tasks")}>
          Login as Task Admin
        </button>
      </div>
    </div>
  )
}
