import "./isp-common.css"

export default function Analytics() {
  return (
    <div className="page">
      <h2 className="page-title">Analytics Summary</h2>

      <div className="grid stats-grid">
        <Stat title="New Users (This Month)" value="142" />
        <Stat title="Churn Rate" value="2.4%" />
        <Stat title="Average Speed Usage" value="320 Mbps" />
      </div>
    </div>
  )
}

function Stat({ title, value }) {
  return (
    <div className="card">
      <p className="stat-title">{title}</p>
      <h3 className="stat-value">{value}</h3>
    </div>
  )
}
