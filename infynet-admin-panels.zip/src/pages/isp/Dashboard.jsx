import "./isp-common.css"

export default function Dashboard() {
  return (
    <>
      <div className="page-header">
        <h2>Dashboard Overview</h2>
        <p>Monitor network performance and subscriptions</p>
      </div>

      <div className="grid grid-3">
        <div className="card stat">
          <span className="icon blue">🌐</span>
          <div>
            <p>Total Providers</p>
            <h3>12</h3>
          </div>
        </div>

        <div className="card stat">
          <span className="icon green">📦</span>
          <div>
            <p>Active Plans</p>
            <h3>8</h3>
          </div>
        </div>

        <div className="card stat">
          <span className="icon orange">👥</span>
          <div>
            <p>Subscribers</p>
            <h3>1,240</h3>
          </div>
        </div>
      </div>
    </>
  )
}

