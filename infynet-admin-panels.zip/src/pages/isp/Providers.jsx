import "./isp-common.css"

export default function Providers() {
  return (
    <div className="page">
      <h2 className="page-title">Internet Service Providers</h2>

      <div className="card table-wrapper">
        <table className="table">
          <thead>
            <tr>
              <th>Provider Name</th>
              <th>Max Speed</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Airtel Fiber</td>
              <td>1 Gbps</td>
              <td className="status active">Active</td>
            </tr>
            <tr>
              <td>Jio Fiber</td>
              <td>500 Mbps</td>
              <td className="status active">Active</td>
            </tr>
            <tr>
              <td>Local ISP</td>
              <td>100 Mbps</td>
              <td className="status inactive">Inactive</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
