export default function Settings() {
  return (
    <div className="card" style={{ maxWidth: 500 }}>
      <h3 style={{ marginBottom: 20 }}>Profile Settings</h3>

      <input placeholder="Admin Name" style={input} />
      <input placeholder="Email" style={input} />
      <input placeholder="Password" type="password" style={input} />

      <button className="btn-primary" style={{ marginTop: 10 }}>
        Save Changes
      </button>
    </div>
  )
}

const input = {
  width: "100%",
  padding: 12,
  marginBottom: 12,
  borderRadius: 8,
  border: "1px solid #e5e7eb",
}
