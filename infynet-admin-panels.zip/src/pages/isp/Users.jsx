import "./isp-common.css"

export default function Users() {
  return (
    <div className="page">
      <h2 className="page-title">Registered Users</h2>

      <div className="card table-wrapper">
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Plan</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Rahul Sharma</td>
              <td>Premium</td>
              <td className="status active">Active</td>
            </tr>
            <tr>
              <td>Anita Verma</td>
              <td>Standard</td>
              <td className="status active">Active</td>
            </tr>
            <tr>
              <td>Mohit Singh</td>
              <td>Basic</td>
              <td className="status inactive">Inactive</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
